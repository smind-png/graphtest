const container = document.getElementById("quiz-container");

questions.forEach((q, index) => {
  const div = document.createElement("div");
  div.classList.add("question");

  const title = document.createElement("p");
  title.textContent = q.question;
  div.appendChild(title);

  q.options.forEach(opt => {
    const label = document.createElement("label");
    const input = document.createElement("input");
    input.type = "radio";
    input.name = `q${index}`;
    input.value = opt;
    label.appendChild(input);
    label.append(" " + opt);
    div.appendChild(label);
    div.appendChild(document.createElement("br"));
  });

  container.appendChild(div);
});

function checkAnswers() {
  const allQuestions = document.querySelectorAll(".question");
  allQuestions.forEach((div, i) => {
    const selected = div.querySelector("input[type=radio]:checked");
    if (!selected) return;

    if (selected.value === questions[i].answer) {
      div.classList.add("correct");
      div.classList.remove("incorrect");
    } else {
      div.classList.add("incorrect");
      div.classList.remove("correct");
    }
  });
}
